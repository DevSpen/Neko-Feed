# Callbacks
Callbacks are commands for triggers which are executed when a certain action is preformed. These actions include banning, unbanning, user joining, user leaving, etc. Callbacks are not used in the command code, they are used in the command trigger. This section will explain the callbacks you can use. 
