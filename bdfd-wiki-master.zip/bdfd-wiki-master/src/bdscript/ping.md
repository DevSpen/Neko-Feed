# $ping
Shows the delay between sent message and bot's response.
The value of `$ping` is expressed in miliseconds.

## Example command:
```
Ping: $ping ms
```

#### Expected output:
```
Ping: 50 ms
```
⠀
