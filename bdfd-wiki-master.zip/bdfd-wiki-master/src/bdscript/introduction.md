# Functions introduction
In this section of wiki you will learn about some of the useful functions.\
Functions *(as the name itself says)* add extra functionality to your commands.\
They are heart and soul of your bot. Remember that functions start with `$`.\
For example `$nomention` or `$ping`.