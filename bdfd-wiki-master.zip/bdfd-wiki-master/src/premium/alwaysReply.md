# $alwaysReply
`$alwaysReply` replies to every message no matter what.

## Example
a. Make the trigger `$alwaysReply`

b. Put something in the reply message/code

![image](https://user-images.githubusercontent.com/69215413/113947987-da3c1480-97d9-11eb-8739-f0630e4fcbd9.png)

![image](https://user-images.githubusercontent.com/69215413/113947993-ddcf9b80-97d9-11eb-9cb4-1b7e33991033.png)

