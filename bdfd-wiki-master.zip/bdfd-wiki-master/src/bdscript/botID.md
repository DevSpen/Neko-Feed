# $botID
Returns the bot's ID.

## Usage
```$botID```

## Example
```My ID is: $botID```

### Expected Output
```My ID is: the-bots-id```

#### Expected Output Sample
```My ID is: 566613317972394004```
