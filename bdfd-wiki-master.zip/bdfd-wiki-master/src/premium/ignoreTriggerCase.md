# $ignoreTriggerCase
*(for premium bots)*

`$ignoreTriggerCase` makes the command trigger __not__ case sensitive. For example, `!help` and `!HeLp` would both work.

## Usage
```$ignoreTriggerCase```
## Example
```
$nomention
$ignoreTriggerCase
Hello World!
```
### Expected Output
```
Hello World!
*ignores command trigger case/caps*
```
![Preview](https://user-images.githubusercontent.com/69215413/113355344-a3b05680-930e-11eb-89a4-27700523218f.png)
