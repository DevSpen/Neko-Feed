# Bot Designer for Discord Wiki
To build wiki you need [mdBook](https://github.com/rust-lang/mdBook)