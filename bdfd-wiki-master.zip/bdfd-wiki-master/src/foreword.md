# Foreword
Welcome to our humble abode. The thing you're seeing is *Bot Designer for Discord*'s wiki.
If you're curious about *functions* please feel free to visit [this section](bdscript/introduction.md).
